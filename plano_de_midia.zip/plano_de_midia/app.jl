using Revise
using Genie, Genie.Router, Genie.Requests
using Genie.Renderer, Genie.Renderer.Html

include("lib/ModelGenie.jl")
using .ModelGenie

# render the form
route("/") do
  html(path"views/formulario.jl.html")
end

route("/model", method=POST) do
  filename = ModelGenie.rodaModelo( parse(Int, payload(:inputInvestimento)),
                                    parse(Int, payload(:inputMeses)),
                                    parse(Int, payload(:inputValorMinimo)),
                                    payload(:inputBuscasMensais),
                                    payload(:inputCPCsMensaisG),
                                    payload(:inputCPCsMensaisFb),
                                    payload(:inputCPCsMensaisIg),
                                    payload(:inputCPCsMensaisDs))

  redirect(filename)
end

route("/sobre") do
  html(path"views/sobre.jl.html")
end

route("/downloads") do
    html(path"views/download.jl.html")
end

up(async=false) # start server and block the repl so it keeps running // ctrl+c to exit
